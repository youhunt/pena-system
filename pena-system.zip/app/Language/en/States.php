<?php

// override core en language system validation or define your own en language validation message
return [
    'States' => 'States',
    'ID' => 'ID',
    'State' => 'State',
    'Country' => 'Country',
];
