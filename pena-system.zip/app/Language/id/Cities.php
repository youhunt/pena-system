<?php

// override core en language system validation or define your own en language validation message
return [
    'Cities' => 'Kota',
    'ID' => 'Kode',
    'City' => 'Kota',
    'State' => 'Propinsi',
    'Country' => 'Negara',
];
