<?php

// override core en language system validation or define your own en language validation message
return [
    'Provinces' => 'Provinces',
    'ID' => 'ID',
    'State' => 'State',
    'Country' => 'Country',
    'province_code' => 'Province Code',
    'province_name' => 'Province Name',
];
