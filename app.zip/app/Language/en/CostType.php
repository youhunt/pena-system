<?php

return [
    'id' => 'ID',
    'type' => 'Cost Type',
    'description' => 'Description',
    'group' => 'Cost Group',
];