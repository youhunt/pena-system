<?php

// override core en language system validation or define your own en language validation message
return [
    'Cities' => 'Cities',
    'ID' => 'ID',
    'City' => 'City',
    'Province' => 'Province',
    'Country' => 'Country',
    'city_code' => 'City Code',
    'city_name' => 'City Name',
];
