<?php

// override core en language system validation or define your own en language validation message
return [
    'id' => 'ID',
    'uom_code' => 'UOM Code',
    'uom_desc' => 'Description',
    'uomdec' => 'Decimals',
];
