<?php

// override core en language system validation or define your own en language validation message
return [
    'id' => 'ID',
    'fr_uom' => 'From UoM',
    'to_uom' => 'To UoM',
    'value' => 'Value',
];
