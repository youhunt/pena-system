<?php

// override core en language system validation or define your own en language validation message
return [
    'id' => 'ID',
    'company' => 'Company',
    'site' => 'Site',
    'dept' => 'Department',
    'transcode' => 'Transaction Code',
    'transname' => 'Transaction Name',
    'module' => 'Module',
    'transtype' => 'Transaction Type',
    'transnumber' => 'Numbering',
    'transdescription' => 'Description',
    'glcode' => 'GL Code',
];