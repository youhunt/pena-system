<?php

// override core en language system validation or define your own en language validation message
return [
    'id' => 'ID',
    'uom_code' => 'Kode',
    'uom_desc' => 'Diskripsi',
    'uomdec' => 'Desimal',
];
