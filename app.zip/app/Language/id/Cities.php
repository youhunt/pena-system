<?php

// override core en language system validation or define your own en language validation message
return [
    'Cities' => 'Kota',
    'ID' => 'Kode',
    'City' => 'Kota',
    'Province' => 'Propinsi',
    'Country' => 'Negara',
    'city_code' => 'Kode Kota',
    'city_name' => 'Kota',
];
