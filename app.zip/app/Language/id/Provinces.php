<?php

// override core en language system validation or define your own en language validation message
return [
    'Provinces' => 'Propinsi',
    'ID' => 'Kode',
    'Province' => 'Propinsi',
    'Country' => 'Negara',
    'province_code' => 'Kode Propinsi',
    'province_name' => 'Nama Propinsi',
];
