<?php

// override core en language system validation or define your own en language validation message
return [
    'id' => 'ID',
    'itemcode' => 'Kode barang',
    'site' => 'Site',
    'dept' => 'Departemen',
    'whs' => 'Gudang',
    'fr_uom' => 'Dari UoM',
    'to_uom' => 'Ke UoM',
    'value' => 'Nilai',
];
