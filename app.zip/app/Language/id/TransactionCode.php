<?php

// override core en language system validation or define your own en language validation message
return [
    'id' => 'ID',
    'company' => 'Perusahaan',
    'site' => 'Lokasi',
    'dept' => 'Departemen',
    'transcode' => 'Kode Transaksi',
    'transname' => 'Nama Transaksi',
    'module' => 'Modul',
    'transtype' => 'Tipe Transaksi',
    'transnumber' => 'No. Transaksi',
    'transdescription' => 'Keterangan',
    'glcode' => 'Kode GL',
];