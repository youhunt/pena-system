<?php

return [
    'id' => 'ID',
    'type' => 'Jenis Biaya',
    'description' => 'Keterangan',
    'group' => 'Kelompok Biaya',
];